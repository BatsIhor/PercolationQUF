 public class Percolation
    {
        private WeightedQuickUnionUF uf;
        private int[][] indexes;
        private boolean[][] openItems;

        private int N;

        // create N-by-N grid, with all sites blocked
        public Percolation(int N)
        {
            uf = new WeightedQuickUnionUF(N * N + 2);

            this.N = N;
            int x = 0;

            indexes = new int[N][N];
            openItems = new boolean[N][N];
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    indexes[i][j] = x;
                    openItems[i][j] = false;
                    x++;
                }
            }

            for (int i = 0; i < N; i++)
            {
                uf.union(N * N, i);
                uf.union(N * N + 1, N * N - N + i);
            }
        }

        // open site (row i, column j) if it is not already
        public void open(int i, int j)
        {
            if (i < 0 || i >= N) throw 
            new IndexOutOfBoundsException("isOpen index i out of bounds " + i);
            if (j < 0 || j >= N) throw 
            new IndexOutOfBoundsException("isOpen index j out of bounds " + i);

            if (!isOpen(i, j))
            {
                openItems[i][j] = true;
            }

            if (i + 1 < N && isOpen(i + 1, j) && 
                !uf.connected(uf.find(indexes[i][j]),
                              uf.find(indexes[i + 1][ j])))
            {
                uf.union(uf.find(indexes[i][j]), uf.find(indexes[i + 1][ j]));
            }

            if (j + 1 < N && isOpen(i, j + 1)  && 
                !uf.connected(uf.find(indexes[i][j]),
                              uf.find(indexes[i][ j + 1])))
            {
                uf.union(uf.find(indexes[i][j]), uf.find(indexes[i][ j + 1]));
            }

            if (i - 1 >= 0 && isOpen(i - 1, j) && 
                !uf.connected(uf.find(indexes[i][j]), 
                              uf.find(indexes[i - 1][ j])))
            {
                uf.union(uf.find(indexes[i][j]), uf.find(indexes[i - 1][ j]));
            }

            if (j - 1 >= 0 && isOpen(i, j - 1)&& 
                !uf.connected(uf.find(indexes[i][j]), 
                              uf.find(indexes[i][ j - 1])))
            {
                uf.union(uf.find(indexes[i][j]), uf.find(indexes[i][ j - 1]));
            }
        }

        // does the system percolate?
        public boolean percolates()
        {
            return uf.find(N * N) == uf.find(N * N + 1);
        }

        // is site (row i, column j) open?
        public boolean isOpen(int i, int j)
        {
             if (i < 0 || i > N) throw 
            new IndexOutOfBoundsException("isOpen index i out of bounds " + i);
             if (j < 0 || j > N) throw 
            new IndexOutOfBoundsException("isOpen index j out of bounds " + j);

            return openItems[i][j];
        }

        // is site (row i, column j) full?
        public boolean isFull(int i, int j)
        {
             if (i < 0 || i > N) throw 
            new IndexOutOfBoundsException("isFull index i out of bounds " + i);
             if (j < 0 || j > N) throw 
            new IndexOutOfBoundsException("isFull index j out of bounds " + j);
        
            return uf.find(indexes[i][j]) == uf.find(N*N);
        }     
    }
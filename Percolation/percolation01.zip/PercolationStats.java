    public class PercolationStats
    {
        private double[] results;
        private String percent = "%";
        private int N;
        private int T;

        // perform T independent computational experiments on an N-by-N grid
        public PercolationStats(int N, int T)
        {
            this.T = T;
            this.N = N;
            results = new double[T];

            for (int i = 0; i < T; i++)
            {
                Percolation percolation = new Percolation(N);
                double inserts = 0;
                while (!percolation.percolates())
                {
                    int x = StdRandom.uniform(0, N);
                    int y = StdRandom.uniform(0, N);

                    if (!percolation.isOpen(x, y))
                    {
                        percolation.open(x, y);
                        inserts++;
                    }
                }
                results[i] = inserts / (N * N);
            }
        }

        // sample mean of percolation threshold
        public double mean()
        {
            return StdStats.mean(results);
        }
        
        // sample standard deviation of percolation threshold
        public double stddev()
        {
            return StdStats.stddev(results);
        }

        // returns lower bound of the 95% confidence interval
        public double confidenceLo()
        {
            double m = mean();
            double d = stddev();
            return m - (1.96 * d) / Math.sqrt(T);
        }

        // returns upper bound of the 95% confidence interval
        public double confidenceHi()
        {
            double m = mean();
            double d = stddev();
            return m + (1.96 * d) / Math.sqrt(T);
        }

        // test client, described below
        public static void main(String[] args)
        {
            if (args.length == 2)
            {
                int N = 5;
                int T = 10;
                
                int val;
                try
                {
                    N = Integer.parseInt(args[0]);
                    T = Integer.parseInt(args[1]);
                }
                catch (NumberFormatException nfe)
                {
                    return;
                }

                PercolationStats percStats = new PercolationStats(N, T);
                System.out.println("mean\t\t\t= " + percStats.mean());
                System.out.println("stddev\t\t\t= " + percStats.stddev());

                double hi = percStats.confidenceHi();
                double lo = percStats.confidenceLo();

                System.out.println("95 confidence interval = " + hi + " " + lo);
            }           
        }
    }